package webapi.demo.pojo;

/**
 * 删除图片接口请求参数
 * 
 * @author wangjun
 *
 */
public class DelTargetRequest {
	/**
	 * 图片ID
	 */
	private long id;

	public DelTargetRequest() {

	}

	public DelTargetRequest(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
}

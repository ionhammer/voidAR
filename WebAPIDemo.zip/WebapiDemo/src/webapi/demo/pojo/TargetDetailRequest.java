package webapi.demo.pojo;

/**
 * 取得图片详细信息接口请求参数
 * 
 * @author wangjun
 *
 */
public class TargetDetailRequest {
	/**
	 * 图片ID
	 */
	private long id;

	public TargetDetailRequest() {

	}

	public TargetDetailRequest(long id) {
		this.id = id;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

}

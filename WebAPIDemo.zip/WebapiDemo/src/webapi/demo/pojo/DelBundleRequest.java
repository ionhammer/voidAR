package webapi.demo.pojo;

/**
 * 删除assetbundle接口请求参数
 * 
 * @author wangjun
 *
 */
public class DelBundleRequest {
	/**
	 * 图片ID
	 */
	private long id;
	/**
	 * 平台
	 */
	private int platform;

	public DelBundleRequest() {

	}

	public DelBundleRequest(long id, int platform) {
		this.id = id;
		this.platform = platform;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getPlatform() {
		return platform;
	}

	public void setPlatform(int platform) {
		this.platform = platform;
	}

}

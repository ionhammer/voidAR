package webapi.demo.pojo;

/**
 * 上传assetbundle接口请求参数
 * 
 * @author wangjun
 *
 */
public class UploadBundleRequest {
	/**
	 * 图片ID
	 */
	private long id;
	/**
	 * 平台
	 */
	private int platform;
	/**
	 * bundle文件（base64编码）
	 */
	private String bundle;

	public UploadBundleRequest() {

	}

	public UploadBundleRequest(long id, int platform, String bundle) {
		this.id = id;
		this.platform = platform;
		this.bundle = bundle;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getPlatform() {
		return platform;
	}

	public void setPlatform(int platform) {
		this.platform = platform;
	}

	public String getBundle() {
		return bundle;
	}

	public void setBundle(String bundle) {
		this.bundle = bundle;
	}

}

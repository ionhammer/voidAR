package webapi.demo.pojo;

import org.apache.commons.lang.StringUtils;

/**
 * 上传图片接口请求参数
 * 
 * @author wangjun
 *
 */
public class AddTargetRequest {
	/**
	 * 名称
	 */
	private String name;
	/**
	 * 自定义数据（base64编码）
	 */
	private String metadata;
	/**
	 * 识别目标数据（base64编码）
	 */
	private String imagedata;

	public AddTargetRequest(String name, String metadata, String imagedata) {
		this.name = name;
		this.metadata = metadata;
		if (StringUtils.isBlank(imagedata)) {
			this.imagedata = "";
		} else {
			this.imagedata = imagedata;
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public String getImagedata() {
		return imagedata;
	}

	public void setImagedata(String imagedata) {
		this.imagedata = imagedata;
	}

}

package webapi.demo.pojo;

/**
 * 取得云数据库图片列表接口请求参数
 * 
 * @author wangjun
 *
 */
public class TargetListRequest {
	/**
	 * 记录开始位置
	 */
	private int start;
	/**
	 * 取得数量
	 */
	private int num;

	public TargetListRequest() {

	}

	public TargetListRequest(int start, int num) {
		this.start = start;
		this.num = num;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

}

package webapi.demo;

import java.io.File;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.Charsets;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import webapi.demo.pojo.AddTargetRequest;

import com.google.gson.Gson;

/**
 * 上传图片接口演示
 * 
 * @author wangjun
 *
 */
public class AddTarget {
	/**
	 * 云数据库accessKey
	 */
	private String accessKey = "ebfc9d27affb4d159167c9cfb175aaf4";
	/**
	 * 云数据库secretKey
	 */
	private String secretKey = "95bbd10c6fb342a485df26d86be43970";
	/**
	 * 接口地址
	 */
	private String url = "http://localhost:8080/develop/ws/uploadTarget.do";
	/**
	 * 识别图片路径
	 */
	private String imgPath = "F:\\imgs4\\10.jpg";

	private String getRequestBody() {
		File imageFile = new File(this.imgPath);
		if (!imageFile.exists()) {
			System.out.println("读取文件错误");
			System.exit(1);
		}
		try {
			byte[] image = FileUtils.readFileToByteArray(imageFile);
			String name = imageFile.getName();
			String metadata = Base64.encodeBase64String("test".getBytes("utf-8"));
			String imagedata = Base64.encodeBase64String(image);
			AddTargetRequest requestBody = new AddTargetRequest(name, metadata, imagedata);
			Gson gson = new Gson();
			return gson.toJson(requestBody);
		} catch (Exception e) {
			return null;
		}
	}

	private void postData() {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		CloseableHttpResponse response = null;
		try {
			String requestBody = this.getRequestBody();
			System.out.println(requestBody);
			if (StringUtils.isBlank(requestBody)) {
				System.out.println("请求数据错误");
				System.exit(1);
			}
			StringEntity entity = new StringEntity(requestBody);
			HttpPost post = new HttpPost(this.url);
			post.setHeader("Content-Type", "application/json");
			post.setHeader("Authorization", this.accessKey + ":" + this.secretKey);
			post.setEntity(entity);
			response = httpclient.execute(post);
			String resp = EntityUtils.toString(response.getEntity(), Charsets.UTF_8);
			System.out.println(resp);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (Exception e) {
				}
			}
			if (httpclient != null) {
				try {
					httpclient.close();
				} catch (Exception e) {
				}
			}
		}
	}

	public static void main(String[] args) {
		AddTarget task = new AddTarget();
		task.postData();
	}
}
